#!/bin/sh

echo Starting DiscoDJ Player

while true; do
  echo Starting node player
  node /usr/share/discodj/player/index.js
done

echo DiscoDJ Player stopped
